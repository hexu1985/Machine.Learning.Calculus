# ch7_3.py
import math

r = 10                                  # 球半径
v = 4/3*math.pi*r**3
print(f'球体积是   : {v:5.1f}')

area = 4*math.pi*r**2
print(f'球表面积是 : {area:5.1f}')





















