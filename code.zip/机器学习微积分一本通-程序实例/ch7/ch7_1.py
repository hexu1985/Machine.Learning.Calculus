# ch7_1.py
from sympy import *

x = Symbol('x')
f = 3*x**2 + 5
print(integrate(f, (x, 0, 2)))
















