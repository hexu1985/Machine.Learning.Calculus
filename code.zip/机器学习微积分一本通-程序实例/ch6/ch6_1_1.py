# ch6_1_1.py
from sympy import *

x = Symbol('x')
a = Symbol('a')
f = a*x
print(integrate(f, x))















