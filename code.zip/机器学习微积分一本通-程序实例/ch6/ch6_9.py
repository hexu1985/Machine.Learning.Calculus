# ch6_9.py
from sympy import *

x = Symbol('x')
f = x**2
print(integrate(f, (x, 1, 3)))















