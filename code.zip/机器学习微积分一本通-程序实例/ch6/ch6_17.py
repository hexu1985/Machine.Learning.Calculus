# ch6_17.py
from sympy import *

x = Symbol('x')
f = -2*x**2 + 2*x +4
print(integrate(f, (x, -1, 2)))















