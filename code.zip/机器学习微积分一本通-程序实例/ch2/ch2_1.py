# ch2_1.py
import matplotlib.pyplot as plt
alchol = 58
for x in range(0, 11):
    if x > 0:
        alchol *= 0.5 
    print(f"当 x = {x:2d}, 酒精浓度 = {alchol}")


          



