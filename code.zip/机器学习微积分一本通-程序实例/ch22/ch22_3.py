# ch22_3.py
import numpy as np

data = 1 / (1 + np.exp(-0.828 * 5 + 4.006))
print(data)











