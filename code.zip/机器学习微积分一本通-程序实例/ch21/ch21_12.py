# ch21_12.py
import numpy as np

x1 = np.exp(0.81093*1)
x2 = np.exp(0.81093*0)
odds_ratio = x1 / x2
print(f'台北市与外县市胜算比= {odds_ratio:6.4f}')

















